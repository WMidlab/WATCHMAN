
#ifndef GLOBAL_H   /* prevent circular inclusions */
#define GLOBAL_H   /* by using protection macros */

#include <stdio.h>

#define DEBUG
//#define VERBOSE

#endif  /* end of protection macro */
