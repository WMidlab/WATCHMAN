/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"



#include "global.h" 
#include "TARGETC_RegisterMap.h"


int test(){

#ifdef DEBUG
   xil_printf("ID_DEBUG\r\n");
#elif defined VERBOSE
   xil_printf("ID_VERBOSE\r\n");
#else
  
   xil_printf("ID_ELSE\r\n");
#endif
}

int main()
{
    init_platform();
	test();	
    xil_printf("\n\r*** Register Write TARGETC *** \n\r");
    
    xil_printf("DLLlocked...");
    
	while(regptr[TC_STATUS_REG] & LOCKED_MASK != LOCKED_MASK){
		usleep(100000); //sleep 100ms
	}
	xil_printf("OK\r\n");

	GetTargetCStatus();
    ControlRegisterWrite(SWRESET_MASK,ENABLE);
    //GetTargetCStatus();
    xil_printf("\r\n");
    //int* registers = XPAR_TARGETC_0_TC_AXI_BASEADDR;

/*    xil_printf("Testing ISEL");
    
    WriteReadBackRegister(TC_DBBIAS_REG,1100);
    
    int isel=0;
    xil_printf("Changing ISEL value\r\n");
    while(regptr[TC_ISEL_REG] <= 4096){
		WriteReadBackRegister(TC_ISEL_REG,isel);
		isel += 100;
	}
	
	isel=4000;
    while(regptr[TC_ISEL_REG] != 0){
		WriteReadBackRegister(TC_ISEL_REG,isel);
		isel -= 100;
	}
*/
    
	//ControlRegisterWrite(SS_TPG_MASK,ENABLE); //REMOVE SWRESET
	sleep(1);
    
   	TestPatternGenerator(0x505);
    sleep(1);
   
    TestPatternGenerator(0xA0A);
    sleep(1);
  
    TestPatternGenerator(0xFFF);
    sleep(1);
    TestPatternGenerator(0x111);
    sleep(1);
    
    TestPatternGenerator(0xCCC);
    sleep(1);
    TestPatternGenerator(0x333);
    sleep(1);
    
/*    WriteReadBackRegister(TC_DBBIAS_REG,1100);
    
    int isel=0;
    xil_printf("Changing ISEL value\r\n");
    while(registers[TC_ISEL_REG] <= 4096){
		WriteReadBackRegister(TC_ISEL_REG,isel);
		isel += 100;
	}
	
	isel=4000;
    while(registers[TC_ISEL_REG] != 0){
		WriteReadBackRegister(TC_ISEL_REG,isel);
		isel -= 100;
	}
*/    
   //	WriteReadBackRegister(TC_VTRIMT_REG,1209);
 
/*    WriteReadBackRegister(TC_VAPBUFF_REG,1100);
    
    int vadjp=0;
    registers[TC_VADJP_REG] = 0;
    xil_printf("Changing VadJP value\r\n");
    while(registers[TC_VADJP_REG] <= 4096){
		WriteReadBackRegister(TC_VADJP_REG,vadjp);
		vadjp += 100;
	}
	
	vadjp=4000;
    while(registers[TC_VADJP_REG] != 0){
		WriteReadBackRegister(TC_VADJP_REG,vadjp);
		vadjp -= 100;
	}
	
	
	WriteReadBackRegister(TC_VANBUFF_REG,1100);
    
    int vadjn=0;
    xil_printf("Changing VadJN value\r\n");
    registers[TC_VADJN_REG] = 0;
    while(registers[TC_VADJN_REG] <= 4096){
		WriteReadBackRegister(TC_VADJN_REG,vadjn);
		vadjn += 100;
	}
	
	vadjn=4000;
    while(registers[TC_VADJN_REG] != 0){
		WriteReadBackRegister(TC_VADJN_REG,vadjn);
		vadjn -= 100;
	}
    */
    cleanup_platform();
    return 0;
}


