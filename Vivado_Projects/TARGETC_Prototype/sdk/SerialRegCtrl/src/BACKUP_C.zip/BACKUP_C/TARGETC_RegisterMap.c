
#include "TARGETC_RegisterMap.h"

int GetTargetCStatus(){
	xil_printf(">> STATUS:\t ");
	decToHexa(regptr[TC_STATUS_REG] );
	xil_printf(" :");
#ifdef VERBOSE 	
	if(regptr[TC_STATUS_REG] & BUSY_MASK)	xil_printf("\t BUSY_MASK");
	if(regptr[TC_STATUS_REG] & LOCKED_MASK)	xil_printf("\t LOCKED_MASK");
	if(regptr[TC_STATUS_REG] & STORAGE_MASK)	xil_printf("\t STORAGE_MASK");
	if(regptr[TC_STATUS_REG] & SSVALID_MASK)	xil_printf("\t SSVALID_MASK");
	
	//if(regptr[TC_STATUS_REG] & RESET_MASK)	xil_printf("\t RESET_MASK");
	xil_printf("\r\n");
#endif	
}

int ControlRegisterWrite(int mask, int actionID){
	
	//int* regptr = XPAR_TARGETC_0_TC_AXI_BASEADDR;
	if(actionID == ENABLE){
		regptr[TC_CONTROL_REG] = regptr[TC_CONTROL_REG] | mask;
	}
	else if (actionID == DISABLE){
		regptr[TC_CONTROL_REG] = regptr[TC_CONTROL_REG] & (0xFFFFFFFF^mask);
	}
	else{
		xil_printf("Error:\t%s\r\n\tNo valid argument {ENABLE/DISABLE}",__func__);
	}
	
	//DEBUG
	
#ifdef VERBOSE 
	xil_printf(">> CONTROL:\t");
	
	if(regptr[TC_CONTROL_REG] & WRITE_MASK)	xil_printf("\t WRITE_MASK");
	if(regptr[TC_CONTROL_REG] & PCLK_MASK)	xil_printf("\t PCLK_MASK");
	if(regptr[TC_CONTROL_REG] & SCLK_MASK)	xil_printf("\t SCLK_MASK");
	if(regptr[TC_CONTROL_REG] & SIN_MASK)	xil_printf("\t SIN_MASK");
	
	if(regptr[TC_CONTROL_REG] & RAMP_MASK)	xil_printf("\t RAMP_MASK");
	if(regptr[TC_CONTROL_REG] & REGCLR_MASK)	xil_printf("\t REGCLR_MASK");
	if(regptr[TC_CONTROL_REG] & SS_INCR_MASK)	xil_printf("\t SS_INCR_MASK");
	if(regptr[TC_CONTROL_REG] & SS_TPG_MASK)	xil_printf("\t SS_TPG_MASK");
	
	if(regptr[TC_CONTROL_REG] & SS_RESET_MASK)	xil_printf("\t SS_RESET_MASK");
	if(regptr[TC_CONTROL_REG] & RDAD_MASK)	xil_printf("\t RDAD_MASK");
	if(regptr[TC_CONTROL_REG] & STARTSTORAGE_MASK)	xil_printf("\t STARTSTORAGE_MASK");
	if(regptr[TC_CONTROL_REG] & SSACK_MASK)	xil_printf("\t SSACK_MASK");
	
	if(regptr[TC_CONTROL_REG] & SWRESET_MASK)	xil_printf("\t SWRESET_MASK");
	xil_printf("\r\n");
#endif
}


/*int WriteRegister(int regID, int regData){
	int* regptr = XPAR_TARGETC_0_TC_AXI_BASEADDR;
	
	regptr[TC_CONTROL_REG] = 0;
	
	regptr[regID] = regData;
	
	regptr[TC_ADDR_REG] = regID;
	regptr[TC_CONTROL_REG] = 1 | RAMP_MASK;
	
	while(regptr[TC_CONTROL_REG] & BUSY_MASK){
		usleep(100000); //sleep 100ms
	}
	regptr[TC_CONTROL_REG] = 0 | RAMP_MASK;
	
	//xil_printf("W:\tReg:%d\tData:%d\r\n",regID,regData);
	xil_printf("W:\tReg: ");
	decToHexa(regID);
	xil_printf("\tData: ");
	decToHexa(regData);
	xil_printf("\r\n");
}*/

int WriteReadBackRegister(int regID, int regData){

	//int* regptr = XPAR_TARGETC_0_TC_AXI_BASEADDR;
	
	//regptr[TC_CONTROL_REG] = 0;
	ControlRegisterWrite(WRITE_MASK,DISABLE);
	
	regptr[regID] = regData;
	regptr[TC_ADDR_REG] = regID;
	
	ControlRegisterWrite(WRITE_MASK ,ENABLE);
	//regptr[TC_CONTROL_REG] = 1 | RAMP_MASK;
	
	while(regptr[TC_STATUS_REG] & BUSY_MASK){
		usleep(100000); //sleep 100ms
	}
	ControlRegisterWrite(WRITE_MASK,DISABLE);
	
	xil_printf("W:\tReg: ");
	decToHexa(regID);
	xil_printf("\tData: ");
	decToHexa(regData);
	xil_printf("\r\n");
	//Dummy Write
	ControlRegisterWrite(WRITE_MASK ,ENABLE);
	
	while(regptr[TC_STATUS_REG] & BUSY_MASK){
		usleep(100000); //sleep 100ms
	}
	ControlRegisterWrite(WRITE_MASK ,DISABLE);
	
	//xil_printf(">>\tRB:\tReg:%d\tData:%d\r\n",regptr[TC_DATA_OUT_REG]>>12,regptr[TC_DATA_OUT_REG] & 0x00000FFF);
	xil_printf("RB:\t");
	decToHexa(regptr[TC_DATA_OUT_REG]);
	xil_printf("\r\n");
}


int TestPatternGenerator(int tpg){

	//int* regptr = XPAR_TARGETC_0_TC_AXI_BASEADDR;
	//Charge TPG in register
	
	WriteReadBackRegister(TC_TPG_REG, tpg);
	
	//Initiate a serial shift-out
	//regptr[TC_CONTROL_REG] = SS_TPG_MASK | SS_INCR_MASK;
	//ControlRegisterWrite(SS_TPG_MASK | SS_INCR_MASK,ENABLE);
	ControlRegisterWrite(SS_TPG_MASK,DISABLE);
	ControlRegisterWrite(SS_INCR_MASK,ENABLE);
	
	usleep(100000); //sleep 100ms	
	ControlRegisterWrite(SS_INCR_MASK,DISABLE);
	usleep(100000);
	
	xil_printf("CH0:\t");
	decToHexa(regptr[TC_eDO_CH0_REG]);
	xil_printf("\t");
	decToBin(regptr[TC_eDO_CH0_REG]);
	xil_printf("\r\n");
	
	xil_printf("CH1:\t");
	decToHexa(regptr[TC_eDO_CH1_REG]);
	xil_printf("\t");
	decToBin(regptr[TC_eDO_CH1_REG]);
	xil_printf("\r\n");
	
	xil_printf("CH2:\t");
	decToHexa(regptr[TC_eDO_CH2_REG]);
	xil_printf("\t");
	decToBin(regptr[TC_eDO_CH2_REG]);
	xil_printf("\r\n");
	
	xil_printf("CH3:\t");
	decToHexa(regptr[TC_eDO_CH3_REG]);
	xil_printf("\t");
	decToBin(regptr[TC_eDO_CH3_REG]);
	xil_printf("\r\n");

	//ControlRegisterWrite(SS_TPG_MASK,DISABLE);
	
	//ACK?
	xil_printf(">> STATUS:\t ");
	decToHexa(regptr[TC_STATUS_REG] );
	xil_printf("\r\n");

	while(regptr[TC_STATUS_REG] & SSVALID_MASK){
		usleep(100000); //sleep 100ms
		ControlRegisterWrite(SSACK_MASK | SS_TPG_MASK,ENABLE);
	}
	xil_printf(">> STATUS:\t ");
	decToHexa(regptr[TC_STATUS_REG] );
	xil_printf("\r\n");
	ControlRegisterWrite(SSACK_MASK,DISABLE);

}

void decToHexa(unsigned int n){
    // char array to store hexadecimal number 
    char hexaDeciNum[100]; 
      
    // counter for hexadecimal number array 
    int i = 0; 
    while(n!=0) 
    {    
        // temporary variable to store remainder 
        int temp  = 0; 
          
        // storing remainder in temp variable. 
        temp = n % 16; 
          
        // check if temp < 10 
        if(temp < 10) 
        { 
            hexaDeciNum[i] = temp + 48; 
            i++; 
        } 
        else
        { 
            hexaDeciNum[i] = temp + 55; 
            i++; 
        } 
          
        n = n/16; 
    } 

    // printing hexadecimal number array in reverse order 
    for(int j=i-1; j>=0; j--){ 
        xil_printf("%c",hexaDeciNum[j]);
    }
     
}

void decToBin(unsigned int n){    
    // char array to store hexadecimal number 
    char BinDeciNum[100]; 
      
    // counter for hexadecimal number array 
    int i = 0; 
    while(n!=0) 
    {    
        // temporary variable to store remainder 
        int temp  = 0; 
          
        // storing remainder in temp variable. 
        temp = n % 2; 
          
        // check if temp < 10 
        if(temp < 10) 
        { 
            BinDeciNum[i] = temp + 48;
            i++; 
        } 
        else
        { 
            BinDeciNum[i] = temp + 55;
            i++; 
        } 
          
        n = n/2; 
    } 
      
    // printing hexadecimal number array in reverse order 
    for(int j=i-1; j>=0; j--) 
        xil_printf("%c",BinDeciNum[j]);
    
     
}
 
